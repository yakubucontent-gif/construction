import { useEffect, useRef } from "react";
import { initThreeScene } from "@/lib/three-utils";

export default function ThreeScene() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      initThreeScene(containerRef.current);
    }
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="w-full h-full"
      data-testid="three-scene-container"
    />
  );
}
