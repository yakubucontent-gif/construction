import { Award, Users, Handshake, ArrowRight } from "lucide-react";

export default function AboutSection() {
  return (
    <section id="about" className="py-24 bg-muted">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 section-animate">
            <div className="inline-block px-4 py-2 bg-accent text-white rounded-full text-sm font-medium">
              <Award className="inline w-4 h-4 mr-2" />
              Established 1947
            </div>
            
            <h2 className="font-montserrat font-bold text-4xl lg:text-5xl text-foreground">
              75+ Years of 
              <span className="text-primary"> Excellence</span>
            </h2>
            
            <p className="text-xl text-muted-foreground leading-relaxed">
              Canada Construction Limited has been at the forefront of Canada's construction industry since 1947. 
              From our humble beginnings in Toronto, we've grown to become one of the most trusted names in 
              construction across the Greater Toronto Area and beyond.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white flex-shrink-0">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">Industry Leadership</h4>
                  <p className="text-muted-foreground">Recognized leaders in construction innovation and sustainable building practices.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center text-white flex-shrink-0">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">Expert Team</h4>
                  <p className="text-muted-foreground">Our skilled professionals bring decades of experience to every project.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center text-white flex-shrink-0">
                  <Handshake className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">Trusted Partnerships</h4>
                  <p className="text-muted-foreground">Long-standing relationships with clients like City of Toronto and University of Toronto.</p>
                </div>
              </div>
            </div>
            
            <button 
              className="px-8 py-4 bg-primary text-white rounded-full font-semibold text-lg hover:bg-primary/90 transition-all duration-300 hover:scale-105"
              data-testid="button-learn-more"
            >
              <ArrowRight className="inline w-5 h-5 mr-2" />
              Learn More About Us
            </button>
          </div>
          
          <div className="relative section-animate">
            <img 
              src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Historic construction project" 
              className="rounded-3xl shadow-2xl hover-lift" 
            />
            
            {/* Floating Stats Cards */}
            <div className="absolute -bottom-8 -left-8 glass-morphism rounded-2xl p-6 text-center">
              <div className="text-3xl font-bold text-primary">1947</div>
              <div className="text-sm text-muted-foreground">Founded</div>
            </div>
            
            <div className="absolute -top-8 -right-8 glass-morphism rounded-2xl p-6 text-center">
              <div className="text-3xl font-bold text-secondary">1000+</div>
              <div className="text-sm text-muted-foreground">Projects</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
