import { useEffect, useRef } from "react";

declare global {
  interface Window {
    L: any;
  }
}

interface ServiceArea {
  name: string;
  lat: number;
  lng: number;
  description: string;
  color: string;
}

const serviceAreas: ServiceArea[] = [
  { name: "Toronto", lat: 43.6532, lng: -79.3832, description: "Downtown, North York, Scarborough, Etobicoke", color: "#1B365D" },
  { name: "Mississauga", lat: 43.5890, lng: -79.6441, description: "Complete coverage of Mississauga region", color: "#FF6B35" },
  { name: "Markham", lat: 43.8561, lng: -79.3370, description: "Richmond Hill, Thornhill, Unionville", color: "#F7931E" },
  { name: "Vaughan", lat: 43.8361, lng: -79.4983, description: "Woodbridge, Thornhill, Maple", color: "#1B365D" },
  { name: "Brampton", lat: 43.7315, lng: -79.7624, description: "Extended service coverage", color: "#FF6B35" },
  { name: "Burlington", lat: 43.3255, lng: -79.7990, description: "Extended service coverage", color: "#F7931E" },
  { name: "Oakville", lat: 43.4675, lng: -79.6877, description: "Extended service coverage", color: "#1B365D" },
  { name: "Richmond Hill", lat: 43.8828, lng: -79.4403, description: "Extended service coverage", color: "#FF6B35" }
];

export default function InteractiveMap() {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;

    // Load Leaflet CSS and JS
    if (!document.getElementById('leaflet-css')) {
      const css = document.createElement('link');
      css.id = 'leaflet-css';
      css.rel = 'stylesheet';
      css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(css);
    }

    if (!window.L) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = () => initializeMap();
      document.head.appendChild(script);
    } else {
      initializeMap();
    }

    function initializeMap() {
      if (!mapRef.current || !window.L) return;

      // Initialize map centered on GTA
      mapInstance.current = window.L.map(mapRef.current, {
        center: [43.6532, -79.3832], // Toronto coordinates
        zoom: 10,
        scrollWheelZoom: false,
        zoomControl: true,
        attributionControl: false
      });

      // Add tile layer
      window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: ''
      }).addTo(mapInstance.current);

      // Add service area markers
      serviceAreas.forEach((area) => {
        // Create custom icon
        const customIcon = window.L.divIcon({
          html: `
            <div style="
              background-color: ${area.color};
              width: 20px;
              height: 20px;
              border-radius: 50%;
              border: 3px solid white;
              box-shadow: 0 2px 8px rgba(0,0,0,0.3);
              position: relative;
            "></div>
          `,
          className: 'custom-marker',
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        });

        // Add marker with popup
        const marker = window.L.marker([area.lat, area.lng], { icon: customIcon })
          .bindPopup(`
            <div style="text-align: center; font-family: 'Open Sans', sans-serif;">
              <h4 style="margin: 0 0 8px 0; color: ${area.color}; font-weight: bold;">${area.name}</h4>
              <p style="margin: 0; font-size: 12px; color: #666;">${area.description}</p>
            </div>
          `)
          .addTo(mapInstance.current);

        // Add subtle pulsing effect
        marker.on('mouseover', () => {
          marker.openPopup();
        });
      });

      // Add coverage circle overlay
      const coverageCircle = window.L.circle([43.6532, -79.3832], {
        color: '#1B365D',
        fillColor: '#1B365D',
        fillOpacity: 0.1,
        radius: 50000, // 50km radius
        stroke: true,
        weight: 2,
        opacity: 0.3
      }).addTo(mapInstance.current);

      // Fit map to show all markers
      const group = new window.L.featureGroup(
        serviceAreas.map(area => 
          window.L.marker([area.lat, area.lng])
        )
      );
      mapInstance.current.fitBounds(group.getBounds().pad(0.1));
    }

    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove();
        mapInstance.current = null;
      }
    };
  }, []);

  return (
    <div className="relative">
      <div 
        ref={mapRef} 
        className="w-full h-[400px] rounded-3xl shadow-2xl overflow-hidden"
        data-testid="interactive-map"
      />
      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-2 text-xs text-gray-600">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-primary rounded-full"></div>
          <span>Primary Areas</span>
        </div>
        <div className="flex items-center space-x-2 mt-1">
          <div className="w-3 h-3 bg-secondary rounded-full"></div>
          <span>Extended Areas</span>
        </div>
      </div>
    </div>
  );
}