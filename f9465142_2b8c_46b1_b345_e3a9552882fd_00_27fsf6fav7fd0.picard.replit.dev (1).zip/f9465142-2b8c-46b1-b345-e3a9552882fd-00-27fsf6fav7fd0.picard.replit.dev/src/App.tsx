import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx?v=CuhR5b_XSWpJhWC70o8L0");import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/home/runner/workspace/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3060a5d4"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/runner/workspace/client/src/App.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Switch, Route } from "/@fs/home/runner/workspace/node_modules/.vite/deps/wouter.js?v=3060a5d4";
import { queryClient } from "/src/lib/queryClient.ts";
import { QueryClientProvider } from "/@fs/home/runner/workspace/node_modules/.vite/deps/@tanstack_react-query.js?v=3060a5d4";
import { Toaster } from "/src/components/ui/toaster.tsx";
import { TooltipProvider } from "/src/components/ui/tooltip.tsx";
import Home from "/src/pages/home.tsx";
import NotFound from "/src/pages/not-found.tsx";
function Router() {
  return /* @__PURE__ */ jsxDEV(Switch, { "data-replit-metadata": "client/src/App.tsx:30:4", "data-component-name": "Switch", children: [
    /* @__PURE__ */ jsxDEV(Route, { "data-replit-metadata": "client/src/App.tsx:31:6", "data-component-name": "Route", path: "/", component: Home }, void 0, false, {
      fileName: "/home/runner/workspace/client/src/App.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { "data-replit-metadata": "client/src/App.tsx:32:6", "data-component-name": "Route", component: NotFound }, void 0, false, {
      fileName: "/home/runner/workspace/client/src/App.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/workspace/client/src/App.tsx",
    lineNumber: 30,
    columnNumber: 5
  }, this);
}
_c = Router;
function App() {
  return /* @__PURE__ */ jsxDEV(QueryClientProvider, { "data-replit-metadata": "client/src/App.tsx:39:4", "data-component-name": "QueryClientProvider", client: queryClient, children: /* @__PURE__ */ jsxDEV(TooltipProvider, { "data-replit-metadata": "client/src/App.tsx:40:6", "data-component-name": "TooltipProvider", children: [
    /* @__PURE__ */ jsxDEV(Toaster, { "data-replit-metadata": "client/src/App.tsx:41:8", "data-component-name": "Toaster" }, void 0, false, {
      fileName: "/home/runner/workspace/client/src/App.tsx",
      lineNumber: 41,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Router, { "data-replit-metadata": "client/src/App.tsx:42:8", "data-component-name": "Router" }, void 0, false, {
      fileName: "/home/runner/workspace/client/src/App.tsx",
      lineNumber: 42,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/home/runner/workspace/client/src/App.tsx",
    lineNumber: 40,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/runner/workspace/client/src/App.tsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
}
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "Router");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/runner/workspace/client/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/runner/workspace/client/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007Ozs7Ozs7Ozs7Ozs7Ozs7QUFYTixTQUFTQSxRQUFRQyxhQUFhO0FBQzlCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyx1QkFBdUI7QUFDaEMsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxjQUFjO0FBRXJCLFNBQVNDLFNBQVM7QUFDaEIsU0FDRSx1QkFBQyw4RkFDQztBQUFBLDJCQUFDLDRGQUFNLE1BQUssS0FBSSxXQUFXRixRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDO0FBQUEsSUFDaEMsdUJBQUMsNEZBQU0sV0FBV0MsWUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLE9BRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUNFLEtBUFFEO0FBU1QsU0FBU0UsTUFBTTtBQUNiLFNBQ0UsdUJBQUMsd0hBQW9CLFFBQVFSLGFBQzNCLGlDQUFDLGdIQUNDO0FBQUEsMkJBQUMsa0dBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUix1QkFBQyxnR0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxPQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUVKO0FBQUNTLE1BVFFEO0FBV1QsZUFBZUE7QUFBSSxJQUFBRCxJQUFBRTtBQUFBQyxhQUFBSCxJQUFBO0FBQUFHLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJTd2l0Y2giLCJSb3V0ZSIsInF1ZXJ5Q2xpZW50IiwiUXVlcnlDbGllbnRQcm92aWRlciIsIlRvYXN0ZXIiLCJUb29sdGlwUHJvdmlkZXIiLCJIb21lIiwiTm90Rm91bmQiLCJSb3V0ZXIiLCJfYyIsIkFwcCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN3aXRjaCwgUm91dGUgfSBmcm9tIFwid291dGVyXCI7XG5pbXBvcnQgeyBxdWVyeUNsaWVudCB9IGZyb20gXCIuL2xpYi9xdWVyeUNsaWVudFwiO1xuaW1wb3J0IHsgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB7IFRvYXN0ZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL3RvYXN0ZXJcIjtcbmltcG9ydCB7IFRvb2x0aXBQcm92aWRlciB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvdG9vbHRpcFwiO1xuaW1wb3J0IEhvbWUgZnJvbSBcIkAvcGFnZXMvaG9tZVwiO1xuaW1wb3J0IE5vdEZvdW5kIGZyb20gXCJAL3BhZ2VzL25vdC1mb3VuZFwiO1xuXG5mdW5jdGlvbiBSb3V0ZXIoKSB7XG4gIHJldHVybiAoXG4gICAgPFN3aXRjaD5cbiAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGNvbXBvbmVudD17SG9tZX0gLz5cbiAgICAgIDxSb3V0ZSBjb21wb25lbnQ9e05vdEZvdW5kfSAvPlxuICAgIDwvU3dpdGNoPlxuICApO1xufVxuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPFF1ZXJ5Q2xpZW50UHJvdmlkZXIgY2xpZW50PXtxdWVyeUNsaWVudH0+XG4gICAgICA8VG9vbHRpcFByb3ZpZGVyPlxuICAgICAgICA8VG9hc3RlciAvPlxuICAgICAgICA8Um91dGVyIC8+XG4gICAgICA8L1Rvb2x0aXBQcm92aWRlcj5cbiAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJmaWxlIjoiL2hvbWUvcnVubmVyL3dvcmtzcGFjZS9jbGllbnQvc3JjL0FwcC50c3gifQ==